# 🚀 Ghid de publicare a site-ului pe coachdesuflet.ro

Acest ghid te conduce pas cu pas pentru a publica site-ul pe internet, folosind **Netlify** — un serviciu gratuit, simplu și foarte rapid.

⏱️ **Timp estimat:** 30-45 minute (prima dată).

---

## De ce Netlify?

- ✅ **Gratuit** pentru site-uri simple ca al tău
- ✅ **Rapid** — site-ul se încarcă în sub o secundă, oriunde în lume
- ✅ **Simplu** — drag-and-drop, fără cunoștințe tehnice
- ✅ **Securizat** — HTTPS automat (lacătul verde din browser)
- ✅ **Formulare gratuite** — formularul de contact și lead magnet funcționează out-of-the-box

Alternative considerate: Vercel (similar), GitHub Pages (mai tehnic), serviciu de hosting românesc (mai scump, mai lent).

---

## 📋 Pe scurt — pașii principali

1. Cumperi domeniul **coachdesuflet.ro** (dacă nu îl ai deja)
2. Creezi cont gratuit pe Netlify
3. Urci folderul site-ului prin drag-and-drop
4. Conectezi domeniul tău cu Netlify
5. Activezi formularele
6. ✨ Site-ul tău e live!

---

## 🌐 PASUL 1 — Cumpără domeniul coachdesuflet.ro

Dacă nu îl ai deja, cumpără-l de la un registrar românesc bun.

**Recomandarea mea:** **RoTLD** (https://www.rotld.ro) — registrar oficial pentru `.ro`. Prețuri corecte, fără surprize.

**Alternative bune:**
- **GoDaddy.com** — foarte simplu, în engleză
- **Hostico.ro** — românesc, suport ok

Cost aproximativ: **~30-50 lei/an** pentru `.ro`.

📌 Important: La înregistrare îți va cere niște date personale (CNP, adresă). E necesar pentru domeniul `.ro`.

---

## ☁️ PASUL 2 — Creează cont gratuit pe Netlify

1. Mergi la **https://www.netlify.com**
2. Apasă **Sign up** (sus-dreapta)
3. Alege metoda de înregistrare:
   - **Cel mai simplu:** "Sign up with email" — folosești emailul tău `dayana@coachdesuflet.ro`
   - Sau "Sign up with Google" — un click și ai cont
4. Confirmă emailul dacă îți cere

✅ Acum ai cont. Vei vedea un panou (dashboard) gol.

---

## 📤 PASUL 3 — Urcă site-ul (prima dată — drag-and-drop)

Pentru prima publicare, cea mai rapidă metodă:

1. În dashboard-ul Netlify, vei vedea o zonă mare scris "**Want to deploy a new site without connecting to Git?**" sau "**Drag and drop your site output folder here**".

   Dacă nu o vezi clar, dă click pe **Sites** în meniul de sus, apoi caută secțiunea de drag-and-drop.

2. Deschide File Explorer pe Windows și navighează la folderul `coachdesuflet`.

3. **Trage întregul folder** `coachdesuflet` direct în zona din browser.

4. Așteaptă 10-30 de secunde. Netlify face upload-ul și site-ul tău este publicat.

5. Vei primi o adresă temporară de genul:
   ```
   https://romantic-curie-123abc.netlify.app
   ```

🎉 **Site-ul tău este deja live, accesibil de oriunde din lume.** Deschide adresa și verifică.

---

## 🏷️ PASUL 4 — Schimbă numele temporar

Numele auto-generat (`romantic-curie-123abc`) e urât. Schimbă-l:

1. În Netlify, dă click pe site-ul tău
2. Apasă **Site settings**
3. La **Site name**, apasă **Change site name**
4. Scrie ceva curat, ex: `coach-de-suflet`
5. Apasă **Save**

Acum site-ul tău este la `https://coach-de-suflet.netlify.app`. Mai bine, dar tot nu e domeniul tău.

---

## 🔗 PASUL 5 — Conectează domeniul coachdesuflet.ro

Aici e partea cea mai delicată. Fără grabă.

### 5a. În Netlify

1. În dashboard-ul site-ului, apasă **Domain settings** (sau **Domain management**)
2. Apasă **Add a domain** sau **Add custom domain**
3. Scrie: `coachdesuflet.ro`
4. Apasă **Verify** apoi **Add domain**
5. Netlify te va întreba dacă vrei și varianta `www.coachdesuflet.ro` — apasă **Yes**

Netlify îți va arăta acum niște adrese (nameserver-e) de genul:

```
dns1.p01.nsone.net
dns2.p01.nsone.net
dns3.p01.nsone.net
dns4.p01.nsone.net
```

**📌 Copiază aceste 4 adrese — vei avea nevoie de ele.**

### 5b. La registrar-ul de unde ai cumpărat domeniul (RoTLD / GoDaddy / etc.)

1. Intră în contul tău
2. Caută secțiunea **DNS Management** sau **Nameservers** sau **Domain management**
3. Caută opțiunea **Change nameservers** (Schimbă servere DNS)
4. Introdu cele 4 adrese pe care le-ai copiat de la Netlify
5. Salvează

⏰ **Aici trebuie să aștepți.** Schimbarea de DNS durează între **30 minute și 24 de ore**, în funcție de rețea. De obicei e gata în 1-2 ore.

### 5c. Verificare

Du-te înapoi în Netlify, în secțiunea Domain settings. Refresh pagina din când în când. Când vei vedea o bifă verde lângă `coachdesuflet.ro`, domeniul e conectat. 🎉

### 5d. Activează HTTPS (lacătul verde)

În Domain settings, ar trebui să vezi o secțiune **HTTPS** sau **SSL**. Netlify activează automat un certificat gratuit (Let's Encrypt). Dacă nu se activează singur în 1 oră, apasă manual butonul **Provision certificate**.

---

## 📨 PASUL 6 — Activează formularele

Site-ul are 2 formulare: cel pentru **lead magnet** (cele 7 întrebări) și cel de **contact**. Pentru ca emailurile să ajungă la tine, trebuie să modificăm puțin formularele.

### 6a. Modifică fișierele

În folderul tău local `coachdesuflet`, deschide pe rând:
- `pages/cele-7-intrebari.html`
- `pages/contact.html`
- `index.html`

În fiecare, caută eticheta `<form ... id="lead-magnet-form">` sau `<form ... id="contact-form">`.

**Adaugă atributele Netlify:**

**Pentru lead-magnet-form:**
```html
<form class="lead-magnet-form" id="lead-magnet-form" name="lead-magnet" netlify netlify-honeypot="bot-field">
  <input type="hidden" name="form-name" value="lead-magnet">
  <p style="display:none;"><label>Lasă acest câmp gol: <input name="bot-field"></label></p>
  <!-- restul câmpurilor existente -->
</form>
```

**Pentru contact-form:**
```html
<form class="contact-form" id="contact-form" name="contact" netlify netlify-honeypot="bot-field">
  <input type="hidden" name="form-name" value="contact">
  <p style="display:none;"><label>Lasă acest câmp gol: <input name="bot-field"></label></p>
  <!-- restul câmpurilor existente -->
</form>
```

### 6b. Re-urcă site-ul

Salvează fișierele și fă din nou drag-and-drop al folderului `coachdesuflet` în Netlify (peste site-ul existent — va înlocui versiunea veche).

### 6c. Verifică formularele

În Netlify dashboard:
1. Apasă pe site-ul tău
2. Mergi la **Forms** în meniul de sus
3. Vei vedea cele 2 formulare detectate
4. **Setări → Form notifications → Add notification** → introduci `dayana@coachdesuflet.ro` ca să primești emailuri când cineva completează un formular

✅ Acum, când cineva trimite formularul, primești emailul direct la `dayana@coachdesuflet.ro`.

---

## 🔄 Cum publici modificări viitoare

De fiecare dată când modifici site-ul (texte, articole noi, imagini):

**Metoda simplă (drag-and-drop):**
1. Intră în Netlify dashboard
2. Apasă pe site-ul tău
3. Mergi la **Deploys** (în meniul de sus)
4. Trage din nou folderul `coachdesuflet` în zona indicată
5. Așteaptă 30 de secunde
6. Gata, modificările sunt live

**Metoda avansată (Git):** mai târziu, când vei fi confortabilă, recomand să conectezi un cont GitHub. Atunci, modificările se publică automat când le faci. Dar pentru moment, drag-and-drop e suficient.

---

## 💰 Costuri lunare

- **Netlify (planul gratuit):** 0 lei/lună
  - Permite 100 GB trafic/lună (mai mult decât suficient pentru tine)
  - 100 trimiteri de formular/lună gratuit
- **Domeniu coachdesuflet.ro:** ~30-50 lei/an (deci ~3-4 lei/lună)

**Total: ~3-4 lei/lună.** Cea mai bună investiție pe care o vei face pentru afacerea ta.

---

## 🆘 Probleme frecvente

### "Site-ul nu se încarcă la coachdesuflet.ro"
👉 Așteaptă mai mult. Schimbarea DNS poate dura până la 24 de ore.

### "Văd avertisment 'Not Secure' în browser"
👉 HTTPS nu s-a activat încă. În Netlify → Domain settings → HTTPS, apasă manual **Provision certificate**.

### "Formularul îmi trimite la mailto: în loc să-l salveze în Netlify"
👉 Înseamnă că nu ai adăugat atributele `netlify` în form. Verifică pasul 6a.

### "Vreau să folosesc un email cu domeniul meu, ex contact@coachdesuflet.ro"
👉 Pentru asta îți trebuie un serviciu de email separat (nu intră în pachetul gratuit Netlify). Recomandare: **Google Workspace** (~7€/lună) sau **Zoho Mail** (gratuit pentru un utilizator).

---

## 🎯 Lista de verificare finală

Înainte să anunți lumea că site-ul tău e gata:

- [ ] Domeniul `coachdesuflet.ro` se încarcă în browser
- [ ] Lacătul verde HTTPS apare în browser
- [ ] Toate paginile se deschid (Acasă, Despre, Sesiuni, Cele 7 Întrebări, Blog, Contact)
- [ ] Link-urile WhatsApp deschid o conversație nouă cu numărul tău
- [ ] Link-urile către Instagram și TikTok funcționează
- [ ] PDF-ul cele 7 întrebări se descarcă când completezi formularul
- [ ] Ai primit un email de test pe `dayana@coachdesuflet.ro` după ce ai completat singură formularul
- [ ] Site-ul arată bine pe telefon (verifică din mobil)

✅ Toate bifate? Felicitări — ești online!

---

## ✨ Sfat final

Nu te grăbi să publici totul perfect din prima. Mai bine publici un site bun astăzi decât unul perfect peste 3 luni. Vei modifica constant pe parcurs.

Și ține minte: oricând te blochezi, scrie-mi pe WhatsApp.

Cu drag și succes,
*— sufletul tehnic din spatele site-ului*
