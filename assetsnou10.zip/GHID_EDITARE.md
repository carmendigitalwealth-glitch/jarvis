# ✏️ Ghid de editare conținut

Acest ghid îți arată cum să modifici **textele, imaginile și informațiile de pe site** — fără să strici nimic. Vei putea face singură 80% din schimbările pe care vei vrea să le aplici în timp.

---

## 🧭 Structura folderelor — ce este unde

```
coachdesuflet/
├── index.html              ← Pagina principală (Acasă)
├── pages/                  ← Toate paginile secundare
│   ├── despre.html
│   ├── sesiuni.html
│   ├── cele-7-intrebari.html
│   ├── blog.html
│   └── contact.html
├── blog/                   ← Articolele de blog
│   ├── iertarea-care-elibereaza.html
│   └── de-ce-nu-poti-spune-nu.html
├── assets/                 ← Imagini și PDF-uri
│   ├── images/
│   │   ├── dayana.jpg     ← Poza ta
│   │   └── logo.jpg       ← Logo-ul
│   └── cele-7-intrebari.pdf
├── css/                    ← Stilurile (NU le edita decât dacă ești sigură)
└── js/                     ← Scripturile (NU le edita)
```

---

## 🛠️ De ce program am nevoie ca să editez?

Recomandarea mea: **Visual Studio Code** (gratuit, simplu, frumos).

Descarcă: **https://code.visualstudio.com**

După instalare:
1. Deschide VS Code
2. File → Open Folder → alege folderul `coachdesuflet`
3. În panoul din stânga vezi toate fișierele. Dă click pe oricare pentru a-l edita.

Alternativă mai simplă: **Notepad++** sau chiar **Notepad** (din Windows). Funcționează, dar nu te ajută vizual.

---

## ✍️ Cum modifici un text

### Exemplu: Vrei să schimbi salutul de pe pagina principală

1. Deschide `index.html` în VS Code
2. Apasă `Ctrl + F` pentru a căuta
3. Scrie ce vrei să găsești, de ex: `bine ai venit`
4. Editorul te duce direct la text:
   ```html
   <span class="hero-greeting">bine ai venit, suflet drag</span>
   ```
5. Înlocuiește **doar textul** dintre `>` și `<`. NU șterge etichetele.

   **Corect:**
   ```html
   <span class="hero-greeting">bună, draga mea</span>
   ```

   **Greșit (ai stricat eticheta):**
   ```html
   <span class="hero-greeting bună, draga mea</span>
   ```

6. Salvează cu `Ctrl + S`
7. În browser, apasă `F5` pentru a vedea schimbarea (după ce ai pornit `npx serve`)

---

## 🖼️ Cum schimbi o imagine

### Cazul 1: Vrei să înlocuiești poza ta

1. Pregătește noua poză: format `.jpg` sau `.png`, proporții 4:5 (verticală), idealmente lățime de ~800px.
2. Redenumește fișierul nou exact ca cel vechi: `dayana.jpg`
3. Înlocuiește fișierul din `assets/images/dayana.jpg` cu noul tău fișier.
4. Reîncarcă site-ul în browser.

Atât. Nu trebuie să modifici niciun cod.

### Cazul 2: Vrei să adaugi o poză nouă (de exemplu pentru articol blog)

1. Pune poza în `assets/images/`, de exemplu `articol-iertare.jpg`
2. În fișierul articolului, adaugă unde vrei:
   ```html
   <img src="/assets/images/articol-iertare.jpg" alt="Descrierea pozei">
   ```

---

## 📞 Cum modifici numărul de telefon / WhatsApp

Numărul tău apare în multe locuri. Cel mai sigur mod:

1. În VS Code, apasă `Ctrl + Shift + F` (căutare în toate fișierele)
2. Caută: `40751608721`
3. Vei vedea toate locurile unde apare. Înlocuiește în fiecare.

⚠️ **Atenție:** ai grijă să modifici numărul în formatul fără +, fără spații, fără paranteze. Doar cifre. Ex: `40751608721` (nu `+40 751 608 721`).

---

## 📧 Cum modifici adresa de email

Aceeași procedură ca la telefon:

1. `Ctrl + Shift + F`
2. Caută: `dayana@coachdesuflet.ro`
3. Înlocuiește în fiecare loc.

---

## 📱 Cum modifici link-urile Instagram / TikTok

Caută în toate fișierele:
- `instagram.com/coachdesuflet` — pentru Instagram
- `tiktok.com/@coachdesuflet` — pentru TikTok

Și înlocuiește cu noile link-uri.

---

## 📝 Cum adaugi un articol nou pe blog

Acesta este cel mai complex caz. Urmează pașii cu atenție.

### Pasul 1 — Copiază un articol existent ca șablon

1. În folderul `blog/`, dă click-dreapta pe `iertarea-care-elibereaza.html`
2. Copy (Ctrl + C), apoi Paste (Ctrl + V)
3. Vei avea acum `iertarea-care-elibereaza - Copy.html`
4. Redenumește-l cu un nume scurt, doar cu litere mici și cratime, fără spații sau diacritice:
   - Bun: `cum-sa-ierti-pe-tine.html`
   - Rău: `Cum să ierți pe tine.html`

### Pasul 2 — Editează conținutul noului articol

Deschide noul fișier în VS Code și modifică:

**a)** Titlul în `<title>`:
```html
<title>Cum să te ierți pe tine · Coach de Suflet</title>
```

**b)** Meta descrierea (apare în Google):
```html
<meta name="description" content="Descrierea ta scurtă a articolului...">
```

**c)** Header-ul paginii (titlul mare):
```html
<span class="eyebrow">Vindecare · 7 min citire</span>
<h1>Cum să te ierți pe tine</h1>
<p class="lead">Subtitlul articolului</p>
```

**d)** Corpul articolului — totul ce este între `<article class="article-content container">` și `</article>`:
- Modifică paragrafele `<p>...</p>`
- Modifică titlurile `<h2>` și `<h3>`
- Citate speciale: `<blockquote>citat aici</blockquote>`

### Pasul 3 — Adaugă articolul în lista blog

Deschide `pages/blog.html` și caută secțiunea cu cardurile articolelor (`<div class="blog-grid">`).

Copiază un card existent și modifică:
- Titlul articolului
- Excerpt-ul (descrierea scurtă)
- Link-ul: schimbă `/blog/iertarea-care-elibereaza.html` cu noul tău fișier

---

## 🎨 Cum modifici culorile site-ului

Toate culorile sunt definite într-un singur loc: `css/style.css`, la începutul fișierului.

Vei vedea:

```css
:root {
  --color-copper: #C97B5E;
  --color-copper-deep: #A85F45;
  --color-rose: #F4E4DC;
  ...
}
```

Modificând aici culoarea cuprului, de exemplu, se schimbă peste tot pe site instant. **Atenție** — schimbă pe rând și verifică. Nu schimba toate culorile odată.

Pentru a alege o culoare nouă: **https://htmlcolorcodes.com/color-picker/**

---

## 🚫 Ce să NU faci

- ❌ Nu șterge fișiere `.css` sau `.js` decât dacă știi exact ce faci.
- ❌ Nu modifica codul SVG (imaginile vectoriale — încep cu `<svg>`). Le poți strica vizual.
- ❌ Nu rearanja folderele. Numele și locația lor sunt referențiate în cod.
- ❌ Nu modifica `index.html`, `style.css`, `pages.css` și `main.js` pentru schimbări mari, fără să faci backup întâi.

---

## 💾 Cum fac backup înainte de modificări

Înainte de orice modificare mai mare:

1. Selectează tot folderul `coachdesuflet`
2. Click-dreapta → Copy
3. Paste într-un alt loc (de ex. Desktop) și redenumește în `coachdesuflet-backup-2026-01-15` (pune data)

Dacă strici ceva, ai mereu unde să te întorci.

---

## 🆘 Am stricat ceva, ce fac?

1. **Nu intra în panică.** Site-ul nu e online încă, deci nu vede nimeni.
2. Restaurează din backup (vezi mai sus).
3. Sau scrie-mi pe WhatsApp ce s-a întâmplat și te ajut.

---

## ✨ Recomandarea mea

Începe cu modificări mici: schimbă un text, salvează, vezi în browser. Repetă.

După 5-6 modificări reușite, vei prinde ritmul. La a 20-a, vei face totul din reflex.

Pentru schimbări mari (un design nou, o pagină nouă completă, modificări la structura de bază), recomandarea mea este să folosești **Claude Code** — un instrument care te ajută să faci modificări complexe prin conversație. Vezi `PROMPT_CLAUDE_CODE.md` pentru detalii.

Cu drag,
*— sufletul tehnic din spatele site-ului*
