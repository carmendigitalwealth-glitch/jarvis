# 📘 Ghid de instalare și rulare locală pe Windows 11

Bun venit, Dayana! Acest ghid te conduce pas cu pas — de la zero, fără cunoștințe de programare — până la momentul în care îți vezi site-ul rulând pe calculatorul tău.

Timp estimat: **15-20 de minute** prima dată. După, durează 30 de secunde să-l pornești.

---

## 1. Dezarhivează proiectul

Ai primit un fișier `.zip`. Apasă click-dreapta pe el, apoi "**Extract All...**" (sau "Extrage totul..." în română) și alege un loc ușor de găsit, de exemplu:

```
C:\Users\Dayana\Documents\coachdesuflet
```

Sau pe Desktop, mai simplu:

```
C:\Users\Dayana\Desktop\coachdesuflet
```

Acesta este "folderul tău de proiect". Tot ce facem mai jos se referă la el.

---

## 2. Instalează Node.js (o singură dată, pentru toată viața)

Node.js este un program care îți permite să rulezi un mic server pe calculatorul tău, ca site-ul să se comporte exact ca pe internet.

**Pași:**

1. Deschide browser-ul și mergi la: **https://nodejs.org**
2. Vei vedea două butoane mari verzi. Apasă pe cel scris **"LTS"** (este versiunea stabilă recomandată).
3. Se va descărca un fișier `.msi`. Dă dublu-click pe el.
4. La instalare:
   - Apasă **Next** la toate ferestrele
   - Bifează "**I accept the license terms**"
   - Lasă opțiunile bifate implicit
   - Apasă **Install** la final (va cere permisiunea Windows — apasă **Yes**)
5. Așteaptă să se termine. Apasă **Finish**.

✅ **Verificare:** Apasă tastele `Windows + R`, scrie `cmd` și apasă Enter. În fereastra neagră care se deschide, scrie:

```
node --version
```

Dacă vezi ceva de genul `v20.11.0`, e perfect. Node.js este instalat.

---

## 3. Pornește site-ul (pașii pe care îi vei face mereu)

### Metoda simplă — cu **3 click-uri**

1. Deschide folderul `coachdesuflet` (cel pe care l-ai dezarhivat la pasul 1).
2. **Click pe bara de adresă** (de sus, unde scrie calea folderului) și **scrie**:
   ```
   cmd
   ```
   Apoi apasă **Enter**. Se va deschide fereastra neagră direct în folderul tău. ✨

3. În fereastra neagră, scrie comanda:
   ```
   npx serve
   ```
   Apasă Enter.

4. **Prima dată** te va întreba dacă vrei să descarci pachetul `serve`. Apasă **`y`** (de la "yes") și Enter. Așteaptă 30 de secunde — instalează ceva.

5. După ce termină, vei vedea un mesaj de genul:
   ```
   Serving!
   - Local:    http://localhost:3000
   - Network:  http://192.168.1.x:3000
   ```

6. Deschide browser-ul (Chrome, Edge, Firefox) și scrie în bara de sus:
   ```
   http://localhost:3000
   ```

🎉 **Site-ul tău se va deschide!**

---

## 4. Cum oprești site-ul

Când vrei să oprești serverul:

- Mergi în fereastra neagră
- Apasă tastele `Ctrl + C` (pe Mac: `Cmd + C`)
- Confirmă cu `y` și Enter dacă întreabă

Poți închide fereastra neagră — totul s-a oprit curat.

---

## 5. De ce am nevoie de această procedură? Nu pot doar să dau dublu-click pe `index.html`?

Tehnic, ai putea. Dar atunci formularele, link-urile interne și unele animații nu vor funcționa corect. **`npx serve`** simulează un server web real, exact ca cel care va găzdui site-ul tău pe internet.

Recomandarea mea: folosește mereu `npx serve` când vrei să previzualizezi modificările tale înainte de a le pune online.

---

## 6. Probleme frecvente

### "npm nu este recunoscut"
👉 Înseamnă că Node.js nu a fost instalat corect. Reia pasul 2. Restartează calculatorul după instalare dacă e nevoie.

### "Port 3000 already in use"
👉 Există deja un server pornit. În fereastra neagră, apasă `Ctrl + C` și încearcă din nou. Sau folosește un alt port:
```
npx serve -p 4000
```
Apoi deschide `http://localhost:4000`

### Site-ul arată ciudat / fără stiluri
👉 Asigură-te că rulezi `npx serve` **din folderul principal** `coachdesuflet`, nu dintr-un subfolder. În fereastra neagră, înainte de comandă, trebuie să vezi calea: `C:\Users\Dayana\...\coachdesuflet>`

### Vreau să închid fereastra neagră dar să țin site-ul deschis
👉 Nu se poate. Atâta timp cât vrei să vezi site-ul în browser, fereastra neagră trebuie să rămână deschisă. O poți minimiza.

---

## 7. Următorii pași

După ce reușești să rulezi site-ul local:

- 📖 Citește **GHID_EDITARE.md** pentru a învăța cum modifici textele, imaginile, sau adăugi articole noi.
- 🚀 Citește **GHID_DEPLOYMENT.md** pentru a învăța cum publici site-ul pe coachdesuflet.ro, ca să-l vadă toată lumea.

---

## ✨ Sfat de la mine

Prima dată e cel mai greu. A doua oară durează 30 de secunde. A treia oară, vei face totul din reflex.

Dacă te blochezi într-un punct, scrie-mi pe WhatsApp și-ți spun pe loc ce să faci. Suntem împreună în asta.

Cu drag,
*— sufletul tehnic din spatele site-ului*
