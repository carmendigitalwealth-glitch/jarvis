# 🤖 Prompt pentru Claude Code — faza 2 a proiectului

Acest fișier conține un **prompt pre-scris** pe care îl folosești când vrei să continui dezvoltarea site-ului cu **Claude Code** (instrumentul de dezvoltare al Anthropic).

---

## Ce este Claude Code?

**Claude Code** este un asistent de programare care rulează direct pe calculatorul tău. Spre deosebire de a discuta cu Claude într-un browser, Claude Code poate:

- Modifica fișiere direct
- Crea fișiere noi
- Rula comenzi în terminal
- Lucra autonom pe baza descrierilor tale

Este perfect pentru când vrei modificări mai mari decât simple editări de text — adăugarea unei pagini noi, integrare cu o platformă, schimbări de design, etc.

Descarcă și instrucțiuni: **https://docs.claude.com/en/docs/claude-code**

---

## 📋 Prompt-ul de pornire — copiază-l și lipește-l la prima conversație cu Claude Code

```
Sunt Dayana — proprietara afacerii Coach de Suflet (coachdesuflet.ro). Sunt coach acreditat și Maestru Reiki, lucrez cu femei pe blocaje emoționale, vindecare relațională, iertare și redescoperire de sine.

CONTEXT PROIECT:
Am un site web construit pe HTML/CSS/JS pur, în acest folder. Structura:
- index.html → Pagina Acasă
- pages/ → Despre, Sesiuni, Cele-7-Întrebări, Blog, Contact
- blog/ → Articole individuale
- assets/ → Imagini și PDF-ul cu cele 7 întrebări
- css/style.css → Stiluri globale (paletă cupru/crem/roz)
- css/pages.css → Stiluri specifice paginilor
- js/main.js → Navigație, animații scroll, formulare

DESIGN SYSTEM:
- Paletă: cupru cald (#C97B5E), cupru profund (#A85F45), roz pudrat (#F4E4DC), crem cald (#FAF6F1), negru profund (#1A1614), auriu lichid (#D4A574). Toate definite ca CSS variables în :root, în style.css.
- Fonturi: Cormorant Garamond (display/serif), DM Sans (body), Dancing Script (logo/script).
- Estetică: soft luminous + mystical subtil, NU mov, ci cupru și roz pal. Feminin, modern, dar cu suflet și cu sensibilitate.
- Tone of voice în texte: cald, autentic, fără clișee de coaching, nu agresiv-comercial. Adresare la persoana a 2-a singular ("tu", "ai") cu blândețe.

CONTACT (de păstrat consistent în toate modificările):
- Nume: Dayana
- WhatsApp: +40 751 608 721 (link: https://wa.me/40751608721)
- Email: dayana@coachdesuflet.ro
- Instagram: https://www.instagram.com/coachdesuflet
- TikTok: https://www.tiktok.com/@coachdesuflet
- Domeniu: coachdesuflet.ro

VALORI BRAND IMPORTANTE (de menționat când e relevant):
- 5% din costul sesiunilor merge la Asociația Mâna Cerească - Centrul Social Sf. Nectarie (preot Florin Dănu), pentru masa caldă copii/bătrâni
- Grup WhatsApp gratuit pentru comunitate feminină (gratuit pentru moment, posibil să devină plătit în viitor)
- Program recomandare: 10% reducere pentru clienta care recomandă
- Prețurile NU se afișează pe site — se comunică pe WhatsApp după conversație
- NU se folosesc testimoniale inventate (poziție etică fermă)

CE VREAU SĂ FAC ACUM:
[AICI DESCRII CE VREI — vezi exemplele de mai jos]

RESPECTĂ CONVENȚIILE EXISTENTE:
- Folosește CSS variables existente din :root, nu introduce culori noi decât dacă chiar e nevoie
- Mențnine structura HTML existentă (nav, hero, secțiuni cu .reveal, footer cu același conținut)
- Folosește același tip de animații (Intersection Observer, .reveal classes)
- Păstrează responsive-ul mobile-first
- Textele să fie în românească, cu diacritice (ă, î, â, ș, ț)
- Nu modifica index.html, style.css și pages.css fără să-mi spui întâi ce schimbi
```

---

## 🎯 Exemple de cereri concrete

Înlocuiește secțiunea "CE VREAU SĂ FAC ACUM" cu una dintre formulările de mai jos, sau cu o cerere proprie:

### Exemplu 1 — Adaugă un articol nou pe blog

```
Vreau să adăugăm un articol nou pe blog cu titlul "5 ritualuri de dimineață care îți schimbă întreaga zi".

Lungime: ~1200-1500 cuvinte. Tonul: blând, practic, scris în vocea mea (vezi articolele existente din /blog/ ca referință de stil).

Structura propusă:
- Intro: de ce dimineața contează (200 cuvinte)
- 5 ritualuri concrete, fiecare cu titlu h3 și 150-200 cuvinte
- Concluzie + CTA către sesiune

Te rog:
1. Creează fișierul în /blog/ritualuri-de-dimineata.html, folosind ca șablon /blog/iertarea-care-elibereaza.html
2. Actualizează /pages/blog.html ca să includă noul articol în lista de carduri (înlocuiește unul dintre cele cu "În curând")
3. Asigură-te că metadatele SEO (title, description) sunt completate
```

### Exemplu 2 — Adaugă o nouă pagină

```
Vreau o pagină nouă numită "Testimoniale" (deși nu am încă) — vreau să o pregătesc pentru când voi avea acordul scris de la primele cliente.

Pagina ar trebui să:
- Aibă un header similar cu celelalte pagini interioare
- O secțiune intro despre importanța povestirilor reale
- Un grid (3 coloane desktop, 1 mobil) cu carduri pentru testimoniale
- Fiecare card să aibă: prenumele (sau inițială), un citat, profesia/contextul (opțional)
- O secțiune finală CTA către WhatsApp

Pentru moment, pune 3 testimoniale cu textul "În curând" și un mesaj cald că pagina se va completa pe măsură ce clientele își dau acordul.

Adaugă link spre pagină în nav-ul tuturor paginilor existente, între "Blog" și "Programare".
```

### Exemplu 3 — Integrare cu un serviciu de email marketing

```
Vreau ca atunci când cineva completează formularul de la "Cele 7 Întrebări", emailul lor să meargă automat într-o listă de pe Mailerlite (sau alternativă similară). Te rog:

1. Recomandă-mi o soluție potrivită pentru începători (Mailerlite, ConvertKit, Brevo etc.) cu argumente
2. După ce aleg, ghidează-mă pas cu pas cum să creez contul și cum să obțin API key-ul / form ID-ul
3. Modifică formularul din /pages/cele-7-intrebari.html și din /index.html ca să trimită direct la API-ul ales
4. Păstrează funcționalitatea actuală de descărcare automată a PDF-ului după completare
5. Adaugă un mesaj clar GDPR de consimțământ pentru newsletter
```

### Exemplu 4 — Re-design pagina principală cu hero diferit

```
Pagina mea principală e ok, dar vreau un hero mai impactant.

Vreau:
- Un hero care ocupă tot ecranul (100vh)
- Background: o imagine de fundal subtilă (pe care o voi alege), cu overlay degrade din culorile mele
- Titlu mare, centrat
- Sub titlu, un buton primar (WhatsApp) și unul secundar (despre)
- Un indicator subtil de scroll jos

Modifică doar secțiunea .hero din index.html și css-ul aferent (.hero* din pages.css). Nu schimba restul paginii.

Înainte să modifici efectiv, arată-mi mock-up textual (cum va arăta HTML-ul) și verifică cu mine.
```

### Exemplu 5 — Optimizare SEO

```
Vreau să optimizez SEO-ul site-ului pentru ca femeile din România care caută "coach de suflet", "terapie reiki", "coaching feminin", "vindecare emoțională" să mă găsească mai ușor.

Te rog:
1. Auditează fiecare pagină existentă și verifică:
   - Are title bun (50-60 caractere, cu cuvinte cheie relevante)?
   - Are meta description bună (150-160 caractere, persuasive)?
   - Are H1 unic și clar?
   - Sunt H2/H3 structurate logic?
   - Atributele alt la imagini sunt completate?

2. Creează un fișier sitemap.xml în rădăcina proiectului

3. Creează un fișier robots.txt

4. Adaugă schema markup (JSON-LD) pentru:
   - Local business (cu datele mele de contact)
   - Articole de blog (Article schema)
   - Pagini FAQ (FAQPage schema unde e cazul)

Arată-mi modificările pas cu pas, ca să învăț pe parcurs.
```

---

## 💡 Sfaturi pentru o conversație bună cu Claude Code

1. **Fii specifică.** "Modifică hero-ul" e vag. "Modifică hero-ul ca să aibă background gradient cuprul→crem și un buton WhatsApp mai mare" e util.

2. **Spune ce să NU modifice.** Dacă e ceva la care ții, menționează. "Nu schimba culorile, doar layout-ul."

3. **Verifică modificările.** După ce Claude Code face schimbări, deschide site-ul local (`npx serve`) și verifică vizual. Dacă ceva nu îți place, spune-i exact ce.

4. **Lucrează în pași mici.** O modificare pe rând. Nu cere 10 lucruri deodată — vei pierde controlul.

5. **Cere explicații.** Dacă nu înțelegi ce a făcut, întreabă: "Explică-mi cum funcționează asta." Vei învăța pe parcurs.

6. **Salvează backup-uri.** Înainte de modificări mari, copiază tot folderul într-un loc separat.

---

## 🛡️ Limita ta de încredere

Claude Code e foarte capabil, dar **nu lăsa niciodată să facă deploy direct pe domeniul tău live**. Lucrează mereu pe folderul local, verifică, și abia apoi urcă pe Netlify prin drag-and-drop. Așa controlezi 100% ce ajunge pe site-ul tău.

---

Mult spor în faza 2, Dayana! Cu acest prompt ai pârghia să adaugi orice îți dorești la site, în ritmul tău.

*— sufletul tehnic din spatele site-ului*
