# 🌸 Coach de Suflet — site-ul tău

Bun venit, Dayana! Acesta este folderul cu tot ce ai nevoie ca să-ți pui site-ul pe internet.

---

## 🚀 Pornește de aici

Citește documentele în această ordine:

### 1. **GHID_INSTALARE_WINDOWS.md** 📘
Instalezi Node.js și pornești site-ul local pe calculatorul tău. **Începe aici, întotdeauna.** Timp: 15-20 min prima dată.

### 2. **GHID_EDITARE.md** ✏️
Înveți cum să modifici texte, imagini, prețuri, articole de blog. Citește când vrei să faci prima ta modificare.

### 3. **GHID_DEPLOYMENT_NETLIFY.md** 🚀
Publici site-ul pe coachdesuflet.ro, pentru toată lumea. Timp: 30-45 min prima dată.

### 4. **PROMPT_CLAUDE_CODE.md** 🤖
Pentru modificări mai mari, mai târziu. Conține prompt-uri gata făcute pentru a lucra cu Claude Code, instrumentul Anthropic.

---

## 📂 Ce e în acest folder

```
coachdesuflet/
├── 📄 index.html              ← Pagina principală
├── 📁 pages/                  ← Despre, Sesiuni, Cele 7 Întrebări, Blog, Contact
├── 📁 blog/                   ← Articole individuale (2 deja scrise)
├── 📁 assets/                 ← Imagini și PDF-ul Cele 7 Întrebări
│   ├── images/
│   └── cele-7-intrebari.pdf
├── 📁 css/                    ← Stiluri vizuale (nu modifica fără să știi)
├── 📁 js/                     ← Comportament interactiv (nu modifica)
├── 📁 pdf-source/             ← Sursa HTML a PDF-ului (dacă vrei să-l regenerezi)
└── 📄 *.md                    ← Ghidurile (asta și celelalte)
```

---

## ✨ Ce este deja gata

✅ **6 pagini complete**: Acasă, Despre Dayana, Sesiuni 1:1, Cele 7 Întrebări, Blog, Contact
✅ **2 articole de blog** scrise în vocea ta:
   - "Iertarea care eliberează"
   - "De ce nu poți să spui nu"
✅ **PDF Cele 7 Întrebări** — design profesional în paleta brand-ului
✅ **Lead magnet funcțional** — formular pentru download PDF
✅ **Formular de contact**
✅ **Design responsive** — arată bine pe mobil, tabletă, desktop
✅ **Animații subtile** — apariții fluide la scroll
✅ **Link-uri WhatsApp** cu mesaje personalizate
✅ **Integrare Instagram & TikTok** (profilurile tale)
✅ **5% donații → Asociația Mâna Cerească** — menționat clar pe site
✅ **Comunitate WhatsApp** — secțiune dedicată
✅ **Program recomandare** — 10% reducere prezentat ca valoare brand

---

## ⏭️ Ce ai de făcut tu

🔲 **Acum:** Citește GHID_INSTALARE_WINDOWS.md și pornește site-ul local
🔲 **După ce-l vezi local:** Decizi dacă vrei modificări înainte de publicare
🔲 **Când ești gata:** Cumperi domeniul coachdesuflet.ro (dacă nu îl ai)
🔲 **Apoi:** Urmezi GHID_DEPLOYMENT_NETLIFY.md
🔲 **În timp:** Adaugi articole noi pe blog, completezi cu testimoniale când ai acordul clientelor

---

## 💌 Sfat de la mine

Site-ul tău are deja **tot ce-i trebuie ca să convertească**:
- Un mesaj clar și autentic
- Un lead magnet care construiește lista de email
- Un CTA puternic spre WhatsApp (canalul tău preferat)
- Un design care comunică încredere și suflet

Nu mai aștepta perfecțiunea. **Publică-l săptămâna asta**, chiar dacă mai vrei să modifici lucruri pe parcurs. Site-ul tău trăiește din momentul în care prima femeie aflată în căutare găsește prin Google ușa ta.

Cu drag și încredere,
*— sufletul tehnic din spatele site-ului*
