<?php
// =====================================================
// admin-leads.php
// Panou admin: Lead-uri (PDF) + Mesaje (Contact)
// ACCES: https://coachdesuflet.ro/admin-leads.php
// =====================================================

session_start();

// ⚠️ SCHIMBĂ PAROLA AICI cu cea pe care ai pus-o tu!
$ADMIN_PASSWORD = 'Dayana2026CoachSuflet!';

// Login
if (isset($_POST['password'])) {
    if ($_POST['password'] === $ADMIN_PASSWORD) {
        $_SESSION['admin_logged_in'] = true;
    } else {
        $error = 'Parolă greșită';
    }
}

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin-leads.php');
    exit;
}

// Export CSV
if (isset($_GET['export']) && isset($_SESSION['admin_logged_in'])) {
    $which = $_GET['export'] === 'contacts' ? 'contact-uri.csv' : 'lead-uri.csv';
    $csv_file = __DIR__ . '/' . $which;
    if (file_exists($csv_file)) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $which . '-' . date('Y-m-d') . '.csv"');
        readfile($csv_file);
        exit;
    }
}

$is_logged_in = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'];
$tab = isset($_GET['tab']) && $_GET['tab'] === 'contacts' ? 'contacts' : 'leads';
?>
<!DOCTYPE html>
<html lang="ro">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin · Coach de Suflet</title>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'DM Sans', sans-serif;
    background: #FAF6F1;
    color: #1A1614;
    min-height: 100vh;
    padding: 2rem 1rem;
  }
  .container { max-width: 1100px; margin: 0 auto; }
  h1 {
    font-family: 'Cormorant Garamond', serif;
    font-size: 2rem;
    color: #C97B5E;
    margin-bottom: 2rem;
  }
  .login-card {
    max-width: 400px;
    margin: 5rem auto;
    background: white;
    padding: 2.5rem;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(168, 95, 69, 0.1);
  }
  .login-card input {
    width: 100%;
    padding: 0.875rem 1rem;
    border: 1px solid rgba(201, 123, 94, 0.3);
    border-radius: 8px;
    font-size: 1rem;
    margin-bottom: 1rem;
    font-family: inherit;
  }
  .login-card input:focus { outline: none; border-color: #C97B5E; }
  button, .btn {
    background: #C97B5E;
    color: white;
    border: none;
    padding: 0.875rem 1.5rem;
    border-radius: 8px;
    font-size: 0.9375rem;
    font-weight: 500;
    cursor: pointer;
    font-family: inherit;
    text-decoration: none;
    display: inline-block;
  }
  button:hover, .btn:hover { background: #A85F45; }
  .error { color: #c53030; margin-bottom: 1rem; font-size: 0.9rem; }
  
  /* Tabs */
  .tabs {
    display: flex;
    gap: 0.5rem;
    margin-bottom: 1.5rem;
    border-bottom: 2px solid rgba(201, 123, 94, 0.2);
  }
  .tab {
    padding: 0.875rem 1.5rem;
    background: transparent;
    color: #8B7B70;
    border: none;
    border-bottom: 3px solid transparent;
    cursor: pointer;
    font-weight: 500;
    text-decoration: none;
    margin-bottom: -2px;
  }
  .tab.active {
    color: #C97B5E;
    border-bottom-color: #C97B5E;
  }
  .tab:hover { background: rgba(201, 123, 94, 0.08); }
  
  .stats {
    display: flex;
    gap: 1.5rem;
    margin-bottom: 2rem;
    flex-wrap: wrap;
  }
  .stat {
    background: white;
    padding: 1.5rem 2rem;
    border-radius: 12px;
    box-shadow: 0 5px 20px rgba(168, 95, 69, 0.08);
    flex: 1;
    min-width: 200px;
  }
  .stat-value {
    font-family: 'Cormorant Garamond', serif;
    font-size: 2.5rem;
    color: #C97B5E;
    line-height: 1;
  }
  .stat-label {
    font-size: 0.875rem;
    color: #4A3F38;
    margin-top: 0.5rem;
    letter-spacing: 0.05em;
  }
  .actions {
    margin-bottom: 1.5rem;
    display: flex;
    gap: 0.75rem;
    flex-wrap: wrap;
  }
  table {
    width: 100%;
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(168, 95, 69, 0.08);
    border-collapse: collapse;
  }
  thead { background: #F5EDE3; }
  th, td {
    text-align: left;
    padding: 1rem 1.25rem;
    font-size: 0.9rem;
    vertical-align: top;
  }
  th {
    font-weight: 600;
    color: #C97B5E;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    font-size: 0.75rem;
    border-bottom: 1px solid rgba(201, 123, 94, 0.2);
  }
  td { border-bottom: 1px solid rgba(201, 123, 94, 0.1); color: #1A1614; }
  tr:last-child td { border-bottom: none; }
  tr:hover { background: #FAF6F1; }
  .mesaj-cell { 
    max-width: 350px;
    white-space: pre-wrap;
    word-wrap: break-word;
  }
  .empty {
    text-align: center;
    padding: 4rem 2rem;
    color: #8B7B70;
    background: white;
    border-radius: 12px;
  }
  @media (max-width: 768px) {
    table { font-size: 0.8rem; }
    th, td { padding: 0.625rem 0.5rem; }
    .stat-value { font-size: 2rem; }
    .mesaj-cell { max-width: 200px; }
  }
</style>
</head>
<body>

<?php if (!$is_logged_in): ?>
<div class="login-card">
  <h1>Admin · Coach de Suflet</h1>
  <form method="post">
    <?php if (isset($error)): ?>
      <div class="error">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <input type="password" name="password" placeholder="Parolă admin" required autofocus>
    <button type="submit">Intră</button>
  </form>
</div>

<?php else: ?>
<div class="container">
  <h1>Admin · Coach de Suflet</h1>
  
  <!-- Tabs -->
  <div class="tabs">
    <a href="?tab=leads" class="tab <?= $tab === 'leads' ? 'active' : '' ?>">
      📥 Lead-uri (Cele 7 Întrebări)
    </a>
    <a href="?tab=contacts" class="tab <?= $tab === 'contacts' ? 'active' : '' ?>">
      ✉ Mesaje Contact
    </a>
  </div>
  
  <?php
  // Citim CSV-ul potrivit
  $csv_file = __DIR__ . ($tab === 'contacts' ? '/contact-uri.csv' : '/lead-uri.csv');
  $items = [];
  
  if (file_exists($csv_file)) {
    $fp = fopen($csv_file, 'r');
    fgetcsv($fp); // sar peste header
    while (($row = fgetcsv($fp)) !== false) {
      $items[] = $row;
    }
    fclose($fp);
    $items = array_reverse($items);
  }
  
  $total = count($items);
  $today_count = 0;
  $week_count = 0;
  $today_str = date('Y-m-d');
  $week_ago = date('Y-m-d', strtotime('-7 days'));
  foreach ($items as $item) {
    if (isset($item[0])) {
      if ($item[0] === $today_str) $today_count++;
      if ($item[0] >= $week_ago) $week_count++;
    }
  }
  ?>
  
  <div class="stats">
    <div class="stat">
      <div class="stat-value"><?= $total ?></div>
      <div class="stat-label">Total <?= $tab === 'contacts' ? 'mesaje' : 'lead-uri' ?></div>
    </div>
    <div class="stat">
      <div class="stat-value"><?= $week_count ?></div>
      <div class="stat-label">Săptămâna asta</div>
    </div>
    <div class="stat">
      <div class="stat-value"><?= $today_count ?></div>
      <div class="stat-label">Astăzi</div>
    </div>
  </div>
  
  <div class="actions">
    <a href="?tab=<?= $tab ?>&export=<?= $tab ?>" class="btn">📥 Descarcă CSV</a>
    <a href="?logout=1" class="btn" style="background: #4A3F38;">Logout</a>
  </div>
  
  <?php if ($total === 0): ?>
    <div class="empty">
      <p style="font-size: 1.125rem; margin-bottom: 0.5rem;">
        <?= $tab === 'contacts' ? 'Niciun mesaj înregistrat încă.' : 'Niciun lead înregistrat încă.' ?>
      </p>
      <p style="font-size: 0.875rem;">Când cineva <?= $tab === 'contacts' ? 'completează formularul Contact' : 'descarcă ghidul' ?>, va apărea aici.</p>
    </div>
  <?php else: ?>
    <table>
      <thead>
        <?php if ($tab === 'contacts'): ?>
          <tr>
            <th>Data</th>
            <th>Ora</th>
            <th>Nume</th>
            <th>Email</th>
            <th>Telefon</th>
            <th>Mesaj</th>
          </tr>
        <?php else: ?>
          <tr>
            <th>Data</th>
            <th>Ora</th>
            <th>Nume</th>
            <th>Email</th>
            <th>Sursa</th>
          </tr>
        <?php endif; ?>
      </thead>
      <tbody>
        <?php foreach ($items as $item): ?>
        <tr>
          <td><?= htmlspecialchars($item[0] ?? '') ?></td>
          <td><?= htmlspecialchars($item[1] ?? '') ?></td>
          <td><strong><?= htmlspecialchars($item[2] ?? '') ?></strong></td>
          <td><a href="mailto:<?= htmlspecialchars($item[3] ?? '') ?>" style="color:#C97B5E;"><?= htmlspecialchars($item[3] ?? '') ?></a></td>
          <?php if ($tab === 'contacts'): ?>
            <td><?= htmlspecialchars($item[4] ?? '-') ?></td>
            <td class="mesaj-cell"><?= htmlspecialchars($item[5] ?? '') ?></td>
          <?php else: ?>
            <td style="font-size: 0.8rem; color: #8B7B70;"><?= htmlspecialchars(parse_url($item[5] ?? '', PHP_URL_HOST) ?? 'direct') ?></td>
          <?php endif; ?>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
<?php endif; ?>

</body>
</html>
