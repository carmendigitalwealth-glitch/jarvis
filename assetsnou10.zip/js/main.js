/* ==========================================================================
   COACH DE SUFLET — JavaScript principal
   ========================================================================== */

(function() {
  'use strict';

  // === NAVIGAȚIE ===
  const nav = document.querySelector('.nav');
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');

  // Schimbare aspect la scroll
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      nav?.classList.add('scrolled');
    } else {
      nav?.classList.remove('scrolled');
    }
  });

  // Toggle meniu mobil
  navToggle?.addEventListener('click', () => {
    navToggle.classList.toggle('active');
    navMenu.classList.toggle('open');
    document.body.style.overflow = navMenu.classList.contains('open') ? 'hidden' : '';
  });

  // Închidere meniu la click pe link
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
      navToggle?.classList.remove('active');
      navMenu?.classList.remove('open');
      document.body.style.overflow = '';
    });
  });

  // Marcare link activ
  const currentPath = window.location.pathname;
  document.querySelectorAll('.nav-link').forEach(link => {
    const linkPath = link.getAttribute('href');
    if (linkPath && currentPath.includes(linkPath) && linkPath !== '/') {
      link.classList.add('active');
    } else if (linkPath === '/index.html' && (currentPath === '/' || currentPath.endsWith('index.html'))) {
      link.classList.add('active');
    }
  });

  // === SCROLL REVEAL ===
  const observerOptions = {
    threshold: 0.05,
    rootMargin: '0px 0px -30px 0px'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  document.querySelectorAll('.reveal').forEach(el => {
    // Dacă elementul e ascuns (display: none pe mobil), îl marcăm ca visible direct
    // ca să nu blocheze nimic
    if (getComputedStyle(el).display === 'none') {
      el.classList.add('visible');
    } else {
      observer.observe(el);
    }
  });

  // === FORMULAR LEAD MAGNET ===
  const leadForm = document.querySelector('#lead-magnet-form');
  leadForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitBtn = leadForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = 'Se trimite...';
    submitBtn.disabled = true;

    const formData = new FormData(leadForm);
    const data = {
      nume: formData.get('nume'),
      email: formData.get('email'),
      data: new Date().toISOString()
    };

    // Salvare locală (backup pe dispozitivul utilizatorului)
    try {
      const existingLeads = JSON.parse(localStorage.getItem('leads') || '[]');
      existingLeads.push(data);
      localStorage.setItem('leads', JSON.stringify(existingLeads));
    } catch (e) { /* localStorage poate fi blocat în Safari private */ }

    // Trimitere date la server pentru înregistrare în CSV
    try {
      await fetch('/save-lead.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `nume=${encodeURIComponent(data.nume)}&email=${encodeURIComponent(data.email)}`
      });
    } catch (e) { /* dacă serverul nu răspunde, continuăm cu download-ul oricum */ }

    // Descărcare PDF - FORȚAT (funcționează pe mobil + desktop)
    try {
      const response = await fetch('/assets/cele-7-intrebari.pdf');
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = 'Cele-7-Intrebari-Coach-de-Suflet.pdf';
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      
      // Cleanup
      setTimeout(() => {
        document.body.removeChild(link);
        URL.revokeObjectURL(blobUrl);
      }, 100);
    } catch (err) {
      // Fallback - dacă fetch eșuează, deschidem PDF-ul direct
      window.open('/assets/cele-7-intrebari.pdf', '_blank');
    }

    // Afișare mesaj de succes (chiar și dacă fetch eșuează)
    leadForm.style.display = 'none';
    const successMsg = document.querySelector('.form-success');
    if (successMsg) successMsg.classList.add('show');
    
    // Marchez secțiunea ca submitted - pentru ajustări CSS pe mobil
    const leadMagnetSection = leadForm.closest('.lead-magnet');
    if (leadMagnetSection) leadMagnetSection.classList.add('lead-magnet-submitted');

    // === Google Analytics 4 - Eveniment: generate_lead ===
    // Asta îi spune lui Google că ai colectat un lead nou.
    // Apare în Analytics la "Evenimente" și "Conversii".
    if (typeof gtag === 'function') {
      gtag('event', 'generate_lead', {
        'event_category': 'lead_magnet',
        'event_label': 'cele_7_intrebari_pdf',
        'value': 1
      });
    }
  });

  // === FORMULAR CONTACT ===
  const contactForm = document.querySelector('#contact-form');
  contactForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitBtn = contactForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = 'Se trimite...';
    submitBtn.disabled = true;

    const formData = new FormData(contactForm);
    const params = new URLSearchParams();
    params.append('nume', formData.get('nume') || '');
    params.append('email', formData.get('email') || '');
    params.append('telefon', formData.get('telefon') || '');
    params.append('mesaj', formData.get('mesaj') || '');

    // Trimitere la server prin PHP
    try {
      await fetch('/save-contact.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params.toString()
      });
    } catch (err) {
      // Dacă serverul nu răspunde, oricum afișăm mesajul de succes
      // Mesajul rămâne în CSV pe server pentru recuperare
      console.warn('Server contact unavailable, lead may not be saved');
    }

    // Afișare mesaj de succes
    contactForm.style.display = 'none';
    const successMsg = contactForm.parentElement.querySelector('.form-success');
    if (successMsg) successMsg.classList.add('show');

    // === Google Analytics 4 - Eveniment: contact_submit ===
    if (typeof gtag === 'function') {
      gtag('event', 'contact_submit', {
        'event_category': 'contact_form',
        'event_label': 'pagina_contact',
        'value': 1
      });
    }

    submitBtn.innerHTML = originalText;
    submitBtn.disabled = false;
  });

  // === SMOOTH SCROLL pentru link-uri interne ===
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const href = this.getAttribute('href');
      if (href === '#') return;
      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        const offset = 100;
        const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - offset;
        window.scrollTo({
          top: targetPosition,
          behavior: 'smooth'
        });
      }
    });
  });

  // === EFECT PARALLAX SUBTIL pe hero ===
  const heroImage = document.querySelector('.hero-image');
  if (heroImage) {
    window.addEventListener('scroll', () => {
      const scrolled = window.pageYOffset;
      if (scrolled < 800) {
        heroImage.style.transform = `translateY(${scrolled * 0.15}px)`;
      }
    });
  }

  // === GOOGLE ANALYTICS - Tracking click pe linkuri WhatsApp ===
  // Asta îți va arăta în Analytics câți oameni apasă pe butonul WhatsApp.
  document.querySelectorAll('a[href*="wa.me"]').forEach(link => {
    link.addEventListener('click', () => {
      if (typeof gtag === 'function') {
        // Detectez de unde a fost apăsat (homepage, contact, etc.)
        const page = window.location.pathname || '/';
        gtag('event', 'whatsapp_click', {
          'event_category': 'contact',
          'event_label': page,
          'value': 1
        });
      }
    });
  });

  // === ANUL CURENT ÎN FOOTER ===
  const yearEl = document.querySelector('#current-year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }


})();
