/* ==========================================================================
   COACH DE SUFLET - JS SPECTACOL
   Intro 4.5s + scroll reveal + ink words
   ========================================================================== */

(function() {
  'use strict';

  /* ============================================================
     1. INTRO - plic cu sigiliu de ceara, ruleaza la fiecare refresh
     ============================================================ */
  function initIntro() {
    var intro = document.getElementById('introOverlay');
    if (!intro) return;
    
    // Daca URL-ul are ?nav=1 -> sarim intro-ul (click pe Acasa din nav)
    if (window.location.search.indexOf('nav=1') !== -1) {
      intro.remove();
      // Curat URL-ul fara reload, sa nu ramana ?nav=1 in bara
      if (window.history && window.history.replaceState) {
        window.history.replaceState({}, document.title, window.location.pathname);
      }
      return;
    }
    
    // Canvas pentru particule de praf (extrem de subtil)
    var canvas = document.getElementById('introParticles');
    var rafId = null;
    
    if (canvas && canvas.getContext) {
      var ctx = canvas.getContext('2d');
      var W, H, particles = [];
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      
      function resize() {
        W = window.innerWidth;
        H = window.innerHeight;
        canvas.width = W * dpr;
        canvas.height = H * dpr;
        canvas.style.width = W + 'px';
        canvas.style.height = H + 'px';
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.scale(dpr, dpr);
      }
      resize();
      window.addEventListener('resize', resize);
      
      function makeParticle() {
        return {
          x: Math.random() * W,
          y: Math.random() * H,
          r: 0.4 + Math.random() * 1.6,
          vx: (Math.random() - 0.5) * 0.12,
          vy: -(0.04 + Math.random() * 0.18),
          opacity: 0.04 + Math.random() * 0.16,
          life: 1,
          maxLife: 500 + Math.random() * 700
        };
      }
      
      var count = W < 768 ? 22 : 40;
      for (var i = 0; i < count; i++) particles.push(makeParticle());
      
      function animate() {
        ctx.clearRect(0, 0, W, H);
        for (var i = 0; i < particles.length; i++) {
          var p = particles[i];
          p.x += p.vx;
          p.y += p.vy;
          p.life -= 1 / p.maxLife;
          var op = p.opacity * p.life;
          ctx.fillStyle = 'rgba(168, 95, 69, ' + op + ')';
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fill();
          if (p.life <= 0 || p.y < -10) {
            particles[i] = makeParticle();
            particles[i].y = H + 10;
          }
        }
        rafId = requestAnimationFrame(animate);
      }
      animate();
    }
    
    function closeIntro() {
      intro.classList.add('fading-out');
      if (rafId) cancelAnimationFrame(rafId);
      setTimeout(function() { 
        if (intro.parentNode) intro.remove(); 
      }, 900);
    }
    
    // Auto-close la 4.8 secunde (timp: sigiliu apare 0.4-1.4s, se sparge 1.1-1.6s, plic deschide 1.2-2.6s, scrisoare iese 2.0-3.4s, text scrie 2.8-4.4s, semnatura 4.0-5.0s)
    var autoClose = setTimeout(closeIntro, 4800);
    
    // Click oriunde dupa 1.5s
    setTimeout(function() {
      intro.addEventListener('click', function() {
        clearTimeout(autoClose);
        closeIntro();
      });
    }, 1500);
  }
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initIntro);
  } else {
    initIntro();
  }
  
  /* ============================================================
     2. SCROLL REVEAL - pentru reveal-soft, scene-divider, quote-elegant, parchment, frame-museum
     ============================================================ */
  function initReveal() {
    if (!('IntersectionObserver' in window)) {
      // fallback - toate vizibile
      document.querySelectorAll('.reveal-soft, .scene-divider, .quote-elegant, .parchment, .frame-museum').forEach(function(el) {
        el.classList.add('in');
      });
      return;
    }
    
    var obs = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -60px 0px' });
    
    document.querySelectorAll('.reveal-soft, .scene-divider, .quote-elegant, .parchment, .frame-museum').forEach(function(el) {
      obs.observe(el);
    });
  }
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initReveal);
  } else {
    initReveal();
  }
  
})();
