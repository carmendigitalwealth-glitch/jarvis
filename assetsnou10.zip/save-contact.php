<?php
// =====================================================
// save-contact.php
// Salvează mesajele de pe formularul Contact
// într-un fișier CSV + trimite notificare prin SMTP
// =====================================================

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$nume    = isset($_POST['nume'])    ? trim($_POST['nume'])    : '';
$email   = isset($_POST['email'])   ? trim($_POST['email'])   : '';
$telefon = isset($_POST['telefon']) ? trim($_POST['telefon']) : '';
$mesaj   = isset($_POST['mesaj'])   ? trim($_POST['mesaj'])   : '';

if (empty($nume) || empty($email) || empty($mesaj)) {
    http_response_code(400);
    echo json_encode(['error' => 'Date incomplete']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Email invalid']);
    exit;
}

// =====================================================
// 1. SALVARE ÎN FIȘIER CSV
// =====================================================

$csv_file = __DIR__ . '/contact-uri.csv';
$file_exists = file_exists($csv_file);
$fp = fopen($csv_file, 'a');

$now = new DateTime('now', new DateTimeZone('Europe/Bucharest'));
$data = $now->format('Y-m-d');
$ora = $now->format('H:i:s');
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

if ($fp) {
    if (!$file_exists) {
        fputcsv($fp, ['Data', 'Ora', 'Nume', 'Email', 'Telefon', 'Mesaj', 'IP'], ',', '"');
    }
    fputcsv($fp, [$data, $ora, $nume, $email, $telefon, $mesaj, $ip], ',', '"');
    fclose($fp);
}

// =====================================================
// 2. TRIMITERE EMAIL PRIN SMTP AUTENTIFICAT
// =====================================================

// ⚠️ CONFIGUREAZĂ ACESTE VALORI (aceleași ca în save-lead.php):
$SMTP_HOST     = 'mail.coachdesuflet.ro';
$SMTP_PORT     = 465;
$SMTP_USER     = 'coachdesuflet@gmail.com';
$SMTP_PASS     = 'cQ~z})FXYR^B!gv(';       // ⚠️ ÎNLOCUIEȘTE cu parola căsuței
$EMAIL_TO      = 'coachdesuflet@gmail.com';
$EMAIL_FROM    = 'coachdesuflet@gmail.com';

$subject = '✉ Mesaj nou de la ' . $nume . ' prin formularul Contact';
$body = "Bună,\r\n\r\n";
$body .= "Ai primit un mesaj nou prin formularul de contact:\r\n\r\n";
$body .= "Nume: " . $nume . "\r\n";
$body .= "Email: " . $email . "\r\n";
if (!empty($telefon)) {
    $body .= "Telefon: " . $telefon . "\r\n";
}
$body .= "Data: " . $data . " " . $ora . "\r\n\r\n";
$body .= "─────────────────────────\r\n";
$body .= "MESAJUL:\r\n";
$body .= "─────────────────────────\r\n\r\n";
$body .= $mesaj . "\r\n\r\n";
$body .= "─────────────────────────\r\n\r\n";
$body .= "Pentru a răspunde, dai pur și simplu Reply la acest email.\r\n\r\n";
$body .= "Cu drag,\r\n";
$body .= "Site-ul tău coachdesuflet.ro\r\n";

function send_smtp($host, $port, $user, $pass, $from, $to, $reply_to, $subject, $body) {
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        ]
    ]);
    
    $socket = @stream_socket_client(
        "ssl://{$host}:{$port}",
        $errno, $errstr, 30,
        STREAM_CLIENT_CONNECT,
        $context
    );
    
    if (!$socket) return false;
    
    $read = function() use ($socket) {
        $response = '';
        while ($line = fgets($socket, 515)) {
            $response .= $line;
            if (substr($line, 3, 1) === ' ') break;
        }
        return $response;
    };
    
    $send = function($cmd) use ($socket, $read) {
        fputs($socket, $cmd . "\r\n");
        return $read();
    };
    
    $banner = $read();
    if (substr($banner, 0, 3) !== '220') { fclose($socket); return false; }
    
    $resp = $send("EHLO localhost");
    if (substr($resp, 0, 3) !== '250') { fclose($socket); return false; }
    
    $resp = $send("AUTH LOGIN");
    if (substr($resp, 0, 3) !== '334') { fclose($socket); return false; }
    
    $resp = $send(base64_encode($user));
    if (substr($resp, 0, 3) !== '334') { fclose($socket); return false; }
    
    $resp = $send(base64_encode($pass));
    if (substr($resp, 0, 3) !== '235') { fclose($socket); return false; }
    
    $resp = $send("MAIL FROM:<{$from}>");
    if (substr($resp, 0, 3) !== '250') { fclose($socket); return false; }
    
    $resp = $send("RCPT TO:<{$to}>");
    if (substr($resp, 0, 3) !== '250') { fclose($socket); return false; }
    
    $resp = $send("DATA");
    if (substr($resp, 0, 3) !== '354') { fclose($socket); return false; }
    
    $email_data = "From: Coach de Suflet <{$from}>\r\n";
    $email_data .= "To: <{$to}>\r\n";
    $email_data .= "Reply-To: <{$reply_to}>\r\n";  // important - reply va merge la cel ce a scris
    $email_data .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
    $email_data .= "MIME-Version: 1.0\r\n";
    $email_data .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $email_data .= "Content-Transfer-Encoding: 8bit\r\n";
    $email_data .= "Date: " . date('r') . "\r\n";
    $email_data .= "\r\n";
    $email_data .= $body;
    $email_data .= "\r\n.";
    
    $resp = $send($email_data);
    if (substr($resp, 0, 3) !== '250') { fclose($socket); return false; }
    
    $send("QUIT");
    fclose($socket);
    
    return true;
}

// IMPORTANT: $email (cel care scrie) devine Reply-To
// Astfel, când dai Reply la notificare, mailul pleacă DIRECT la persoana care a scris
$sent = send_smtp($SMTP_HOST, $SMTP_PORT, $SMTP_USER, $SMTP_PASS, $EMAIL_FROM, $EMAIL_TO, $email, $subject, $body);

echo json_encode([
    'success' => true,
    'message' => 'Mesaj înregistrat',
    'email_sent' => $sent
]);
